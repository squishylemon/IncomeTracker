﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Threading;
using System.Linq;
using System.Text;

using System.Threading.Tasks;
using System.Windows.Forms;

namespace WeeklyIncomeTracker
{

    public partial class IncomeTracker : Form
    {
        public string CurName;
        public float AmEarned;
        public string curItem;
        public float HrsWorked;


        public IncomeTracker()
        {
            InitializeComponent();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            SaveMods();
            this.Close();
        }

        private async void button3_ClickAsync(object sender, EventArgs e)
        {
           
            

            Form2 Frm2 = new Form2();
            Frm2.Awnsered = false;
            Frm2.dq = true;
            Frm2.DESCRIPTION = "What is the name of the completed task. e.g. Dishes Washed";
            Frm2.timeoption = false;
            Frm2.ShowDialog();
            Frm2.Refresh();
           
            
            CompletedTaskName.Items.Add(Frm2.OUTPUT);
            TimeToCompleteTask.Items.Add(Frm2.OUTPUT2);
            DateOfCompletionBox.Items.Add("" + DateTime.Today);
            RefreshData();

        }
        public void RefreshData()
        {
            AmEarned = 0;
            foreach (var item in TimeToCompleteTask.Items)
            {
                AmEarned = AmEarned + float.Parse(item.ToString());
            }
            HrsWorked = AmEarned;
            AmEarned = AmEarned * 15;
            label1.Text = "" + CurName + " Has Earned " + AmEarned.ToString("c") + " For " + HrsWorked + "Hrs Of Work";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            LoadArwyn();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            LoadAlex();
        }

        public void LoadAlex()
        {
           SaveMods();
            SaveSetts();    
            DateOfCompletionBox.Items.Clear();
            DateOfCompletionBox.DataSource = Properties.Settings.Default.AlexanderTasksDate;
            TimeToCompleteTask.Items.Clear();
            TimeToCompleteTask.DataSource = Properties.Settings.Default.AlexanderTasksTime;
            CompletedTaskName.Items.Clear();
            CompletedTaskName.DataSource = Properties.Settings.Default.AlexanderTasksName;
            CurName = "Alexander";
            RefreshData();
        }
        public void LoadArwyn()
        {
            SaveMods();
            SaveSetts();
            DateOfCompletionBox.Items.Clear();
            DateOfCompletionBox.DataSource = Properties.Settings.Default.ArwynTasksDate;
            TimeToCompleteTask.Items.Clear();
            TimeToCompleteTask.DataSource = Properties.Settings.Default.ArwynTasksTime;
            CompletedTaskName.Items.Clear();
            CompletedTaskName.DataSource = Properties.Settings.Default.AwrynTasksName;
            CurName = "Arwyn";
            RefreshData();
        }
        public void SaveSetts()
        {
            Properties.Settings.Default.Save();
        }
        

        public void SaveMods()
        {

            if (CurName != null)
            {
                if (CurName == "Alexander")
                {
                    foreach (string item in DateOfCompletionBox.Items)
                    {
                        curItem = item.ToString();
                        Console.Write(curItem);
                        p\


                    }
                    foreach (var item in TimeToCompleteTask.Items)
                    {
                        Properties.Settings.Default.AlexanderTasksTime.Add(item.ToString());
                    }
                    foreach (var item in CompletedTaskName.Items)
                    {
                        Properties.Settings.Default.AlexanderTasksName.Add(item.ToString());
                    }

                }
                else
                {
                    foreach (var item in DateOfCompletionBox.Items)
                    {
                        Properties.Settings.Default.ArwynTasksDate.Add(item.ToString());
                    }
                    foreach (var item in TimeToCompleteTask.Items)
                    {
                        Properties.Settings.Default.ArwynTasksTime.Add(item.ToString());
                    }
                    foreach (var item in CompletedTaskName.Items)
                    {
                        Properties.Settings.Default.AwrynTasksName.Add(item.ToString());
                    }
                }
            }
        }
    }
}
